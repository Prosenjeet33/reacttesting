module.exports = require('kcd-scripts/prettier')
