# Cheat sheet design

The cheat sheet document has been created using the desktop publishing software called Affinity Publisher, the original source file can be found in this folder

## Fonts used

- Menlo
- Arial

## Standard distances

15pt between boxes
8pt margin from box edge to inner text